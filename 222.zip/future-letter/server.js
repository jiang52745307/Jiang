const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const nodemailer = require('nodemailer');
const mongoose = require('mongoose'); // 新增 MongoDB 依赖
const path = require('path');

// 初始化 Express
const app = express();
const PORT = process.env.PORT || 3000;
const CHECK_INTERVAL = process.env.CHECK_INTERVAL || 60000;

// 连接 MongoDB 数据库
mongoose.connect(process.env.MONGODB_URI, { 
  useNewUrlParser: true, 
  useUnifiedTopology: true 
})
.then(() => console.log('MongoDB 连接成功'))
.catch(err => console.error('MongoDB 连接失败:', err));

// 定义信件数据模型
const letterSchema = new mongoose.Schema({
  email: { type: String, required: true },
  futureDate: { type: Date, required: true },
  subject: { type: String, required: true },
  message: { type: String, required: true },
  sent: { type: Boolean, default: false }
});
const Letter = mongoose.model('Letter', letterSchema);

// 中间件
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '/')));

// 路由：接收信件
app.post('/api/send-letter', async (req, res) => {
  const { email, futureDate, subject, message } = req.body;
  
  if (!email || !futureDate || !subject || !message) {
    return res.status(400).json({ success: false, message: '所有字段都是必填的' });
  }

  try {
    // 创建信件对象
    const letter = new Letter({
      email,
      futureDate: new Date(futureDate),
      subject,
      message,
      sent: false
    });

    // 判断是否立即发送
    const now = new Date();
    const isSendNow = new Date(futureDate) <= now || new Date(futureDate).getTime() - now.getTime() < 60000;

    if (isSendNow) {
      // 发送邮件逻辑（保持原有代码不变）
      // ...
      // 邮件发送成功后，保存到数据库
      letter.sent = true;
      await letter.save();
      return res.json({ success: true, message: '测试邮件已发送' });
    } else {
      // 保存到数据库
      await letter.save();
      return res.json({ success: true, message: '信件已保存，将在指定时间发送' });
    }
  } catch (error) {
    console.error('保存信件失败:', error);
    return res.status(500).json({ success: false, message: '服务器错误' });
  }
});

// 定时检查并发送邮件（修改后的逻辑）
async function checkAndSendLetters() {
  try {
    const unsentLetters = await Letter.find({ sent: false });
    const now = new Date();

    for (const letter of unsentLetters) {
      if (letter.futureDate <= now) {
        // 发送邮件逻辑（保持原有代码不变）
        // ...
        // 发送成功后更新数据库
        letter.sent = true;
        await letter.save();
      }
    }
  } catch (error) {
    console.error('检查邮件失败:', error);
  }
}

// 删除原有的文件存储相关函数（saveLettersToFile 和 loadLettersFromFile）

// 其他路由（/test-mail、/mail-status 等）保持不变

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
  setInterval(checkAndSendLetters, CHECK_INTERVAL); // 定时任务
});